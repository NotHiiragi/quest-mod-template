cargo ndk -t arm64-v8a -o ./build build --release

Exit $LASTEXITCODE